from django.apps import AppConfig


class CustomerManagementServiceConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "Customer_Management_Service"
